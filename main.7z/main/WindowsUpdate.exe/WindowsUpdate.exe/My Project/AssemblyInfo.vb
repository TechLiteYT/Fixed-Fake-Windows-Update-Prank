﻿Imports System.Resources
Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Windows 10 Update Center")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("xJulek")>
<Assembly: AssemblyProduct("Windows 10 Update Center")>
<Assembly: AssemblyCopyright("Copyright ©  2020")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("2045aa4f-9188-4f46-b0e4-c11e95d1e5a2")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("1.5.8.2")>
<Assembly: AssemblyFileVersion("2.0.0.0")>
<Assembly: NeutralResourcesLanguage("")>
