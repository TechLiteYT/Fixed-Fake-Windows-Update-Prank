﻿Public Class Form2
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form3.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form3.Close()
        MsgBox("Please wait a few minutes until the popups will appear!", MsgBoxStyle.Exclamation, "Fake Windows 10 Update Center")
        Timer1.Start()
        Me.Hide()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        NotifyIcon1.ShowBalloonTip(1000, "Critical updates have been found!", "Your computer is vulnerable to the, most types of ransomware. Click here, to install updates.", ToolTipIcon.Error)
    End Sub

    Private Sub NotifyIcon1_BalloonTipClicked(sender As Object, e As EventArgs) Handles NotifyIcon1.BalloonTipClicked
        Timer1.Stop()
        Form1.Show()
    End Sub
End Class